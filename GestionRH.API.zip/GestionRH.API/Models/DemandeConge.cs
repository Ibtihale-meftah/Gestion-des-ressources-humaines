﻿namespace GestionRH.API.Models
{
    public class DemandeConge
    {
        public int Id { get; set; }
        public int EmployeId { get; set; }
        public Employe Employe { get; set; }
        public DateTime DateDebut { get; set; }
        public DateTime DateFin { get; set; }
        public string Motif { get; set; }
        public StatutConge Statut { get; set; }
        public DateTime DateDemande { get; set; }
        public string? CommentaireRH { get; set; }
        public DemandeConge()
        {
        }

        public DemandeConge(
            int id,
            int employeId,
            Employe employe,
            DateTime dateDebut,
            DateTime dateFin,
            string motif,
            StatutConge statut,
            DateTime dateDemande,
            string commentaireRH
        )
        {
            Id = id;
            EmployeId = employeId;
            Employe = employe;
            DateDebut = dateDebut;
            DateFin = dateFin;
            Motif = motif;
            Statut = statut;
            DateDemande = dateDemande;
            CommentaireRH = commentaireRH;
        }
    }
}
