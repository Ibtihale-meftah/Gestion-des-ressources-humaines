﻿namespace GestionRH.API.Models
{
    public class Poste
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public int JoursCongesAnnuels { get; set; }

        public Poste()
        {
        }

        public Poste(
            int id,
            string nom,
            int joursCongesAnnuels
        )
        {
            Id = id;
            Nom = nom;
            JoursCongesAnnuels = joursCongesAnnuels;
        }
    }
}
