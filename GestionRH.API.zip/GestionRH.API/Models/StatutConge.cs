﻿namespace GestionRH.API.Models
{
    public enum StatutConge
    {
        EnAttente,
        Approuve,
        Refuse
    }
}
