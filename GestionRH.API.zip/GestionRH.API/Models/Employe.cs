﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace GestionRH.API.Models
{
    public class Employe
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Email { get; set; }
        public string MotDePasse { get; set; }
        public int PosteId { get; set; }

        [ValidateNever]
        public Poste Poste { get; set; }
        public bool EstRH { get; set; }
        public int JoursCongesRestants { get; set; }
        public List<DemandeConge> DemandesConges { get; set; }

        public Employe()
        {
            DemandesConges = new List<DemandeConge>();
        }

        public Employe(
            int id,
            string nom,
            string prenom,
            string email,
            string motDePasse,
            int posteId,
            Poste poste,
            bool estRH,
            int joursCongesRestants,
            List<DemandeConge> demandesConges
        )
        {
            Id = id;
            Nom = nom;
            Prenom = prenom;
            Email = email;
            MotDePasse = motDePasse;
            PosteId = posteId;
            Poste = poste;
            EstRH = estRH;
            JoursCongesRestants = joursCongesRestants;
            DemandesConges = demandesConges ?? new List<DemandeConge>();
        }
    }
}
