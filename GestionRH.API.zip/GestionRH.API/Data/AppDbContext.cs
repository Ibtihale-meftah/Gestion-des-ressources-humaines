﻿using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Employe> Employes { get; set; }
    public DbSet<Poste> Postes { get; set; }
    public DbSet<DemandeConge> DemandesConges { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Employe>()
            .HasOne(e => e.Poste)
            .WithMany()
            .HasForeignKey(e => e.PosteId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<DemandeConge>()
            .HasOne(d => d.Employe)
            .WithMany(e => e.DemandesConges)
            .HasForeignKey(d => d.EmployeId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Employe>()
            .Property(e => e.Nom)
            .IsRequired();

        modelBuilder.Entity<Employe>()
            .Property(e => e.Prenom)
            .IsRequired();

        modelBuilder.Entity<Employe>()
            .Property(e => e.Email)
            .IsRequired();

        modelBuilder.Entity<Employe>()
            .Property(e => e.PosteId)
            .IsRequired();

        modelBuilder.Entity<Poste>()
            .Property(p => p.Nom)
            .IsRequired();

        modelBuilder.Entity<DemandeConge>()
            .Property(d => d.Motif)
            .IsRequired();

        modelBuilder.Entity<DemandeConge>()
            .Property(d => d.EmployeId)
            .IsRequired();

        modelBuilder.Entity<DemandeConge>()
            .Property(d => d.Statut)
            .HasConversion<int>()
            .IsRequired();
    }
}