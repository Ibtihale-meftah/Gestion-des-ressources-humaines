﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace GestionRH.API.Controllers
{
    public class AuthController : Controller
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string motDePasse)
        {
            try
            {
                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(motDePasse))
                {
                    ViewBag.Error = "Veuillez remplir tous les champs";
                    return View();
                }

                var employe = await _context.Employes
                  .Include(e => e.Poste)
                  .FirstOrDefaultAsync(e => e.Email == email && e.MotDePasse == motDePasse);

                if (employe == null)
                {
                    ViewBag.Error = "Email ou mot de passe incorrect";
                    return View();
                }

           
                HttpContext.Session.SetInt32("EmployeId", employe.Id);
                HttpContext.Session.SetString("EstRH", employe.EstRH.ToString());
                HttpContext.Session.SetString("Email", employe.Email);
                HttpContext.Session.SetString("Nom", employe.Nom);
                HttpContext.Session.SetString("Prenom", employe.Prenom);

   
                if (employe.EstRH)
                {
          
                    return RedirectToAction("Account", "Employe");
                }
                else
                {
 
                    return RedirectToAction("Details", "Employe", new { id = employe.Id });
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Erreur : {ex.Message}";
                return View();
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}