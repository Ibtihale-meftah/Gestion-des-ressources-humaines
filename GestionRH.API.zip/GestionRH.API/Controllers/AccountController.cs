﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;

namespace GestionRH.API.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

      
        public IActionResult Login()
        {
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Veuillez remplir tous les champs";
                return View();
            }

            var employe = await _context.Employes
                .Include(e => e.Poste)
                .FirstOrDefaultAsync(e => e.Email == email && e.MotDePasse == password);

            if (employe == null)
            {
                ViewBag.Error = "Email ou mot de passe incorrect";
                return View();
            }

          
            HttpContext.Session.SetInt32("EmployeId", employe.Id);
            HttpContext.Session.SetString("Email", employe.Email);
            HttpContext.Session.SetString("Nom", employe.Nom);
            HttpContext.Session.SetString("Prenom", employe.Prenom);
            HttpContext.Session.SetString("EstRH", employe.EstRH.ToString());

           
            return RedirectToAction("Account", "Employe");
        }


        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}