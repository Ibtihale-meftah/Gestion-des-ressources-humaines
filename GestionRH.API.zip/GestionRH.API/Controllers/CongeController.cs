﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;

namespace GestionRH.API.Controllers
{
    public class CongeController : Controller
    {
        private readonly AppDbContext _context;
        private readonly object employeId;

        public CongeController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.DemandesConges.Include(d => d.Employe);
            return View(await appDbContext.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var demandeConge = await _context.DemandesConges
                .Include(d => d.Employe)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (demandeConge == null)
            {
                return NotFound();
            }

            return View(demandeConge);
        }

        public IActionResult Create()
        {
            ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet");
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeId,DateDebut,DateFin,Motif,Statut,DateDemande,CommentaireRH")] DemandeConge demandeConge)
        {
            if (!ModelState.IsValid)
            {
                var errors = string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                TempData["ErrorMessage"] = $"Erreurs de validation : {errors}";
                ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet", demandeConge.EmployeId);
                return View(demandeConge);
            }

            try
            {
                demandeConge.DateDemande = DateTime.Now;
                _context.Add(demandeConge);
                var result = await _context.SaveChangesAsync();
                
                if (result > 0)
                {
                    TempData["SuccessMessage"] = "La demande de congé a été créée avec succès.";
                }
                else
                {
                    TempData["ErrorMessage"] = "Aucune modification n'a été enregistrée.";
                }
                
                return RedirectToAction("Details", new { id = employeId });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Erreur lors de la création : {ex.Message}";
                ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet", demandeConge.EmployeId);
                return View(demandeConge);
            }
            ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet", demandeConge.EmployeId);
            return View(demandeConge);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var demandeConge = await _context.DemandesConges.FindAsync(id);
            if (demandeConge == null)
            {
                return NotFound();
            }
            ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet", demandeConge.EmployeId);
            return View(demandeConge);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,EmployeId,DateDebut,DateFin,Motif,Statut,DateDemande,CommentaireRH")] DemandeConge demandeConge)
        {
            if (id != demandeConge.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(demandeConge);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "La demande de congé a été modifiée avec succès.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DemandeCongeExists(demandeConge.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeId"] = new SelectList(_context.Employes.Select(e => new { e.Id, NomComplet = $"{e.Prenom} {e.Nom}" }), "Id", "NomComplet", demandeConge.EmployeId);
            return View(demandeConge);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var demandeConge = await _context.DemandesConges
                .Include(d => d.Employe)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (demandeConge == null)
            {
                return NotFound();
            }

            return View(demandeConge);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var demandeConge = await _context.DemandesConges.FindAsync(id);
            if (demandeConge != null)
            {
                _context.DemandesConges.Remove(demandeConge);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "La demande de congé a été supprimée avec succès.";
            }
            else
            {
                TempData["ErrorMessage"] = "La demande de congé n'a pas été trouvée.";
            }

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Demandes()
        {
            var demandes = await _context.DemandesConges
                .Include(d => d.Employe)
                .ThenInclude(e => e.Poste)
                .Where(d => d.Statut == StatutConge.EnAttente)
                .OrderBy(d => d.DateDemande)
                .ToListAsync();

            return View(demandes);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approuver(int id)
        {
            var demande = await _context.DemandesConges
                .Include(d => d.Employe)
                .FirstOrDefaultAsync(d => d.Id == id);

            if (demande == null)
                return NotFound();

            int joursDemandes = (demande.DateFin - demande.DateDebut).Days + 1;

            if (demande.Employe.JoursCongesRestants < joursDemandes)
            {
                TempData["ErrorMessage"] = "Solde de congés insuffisant.";
                return RedirectToAction(nameof(Demandes));
            }

            demande.Statut = StatutConge.Approuve;
            demande.Employe.JoursCongesRestants -= joursDemandes;

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Congé approuvé.";
            return RedirectToAction(nameof(Demandes));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Refuser(int id)
        {
            var demande = await _context.DemandesConges.FindAsync(id);

            if (demande == null)
                return NotFound();

            demande.Statut = StatutConge.Refuse;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Congé refusé.";
            return RedirectToAction(nameof(Demandes));
        }

        private bool DemandeCongeExists(int id)
        {
            return _context.DemandesConges.Any(e => e.Id == id);
        }
    }
}
