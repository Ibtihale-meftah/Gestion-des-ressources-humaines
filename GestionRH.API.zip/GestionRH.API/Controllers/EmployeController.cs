﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;
using Microsoft.AspNetCore.Http;

namespace GestionRH.API.Controllers
{
    public class EmployeController : Controller
    {
        private readonly AppDbContext _context;

        public EmployeController(AppDbContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Account()
        {
            var employeId = HttpContext.Session.GetInt32("EmployeId");
            if (employeId == null)
                return RedirectToAction("Login", "Auth");

            if (HttpContext.Session.GetString("EstRH") != "True")
                return RedirectToAction("Details", new { id = employeId });

            var employes = await _context.Employes
                .Include(e => e.Poste)
                .Include(e => e.DemandesConges)
                .ToListAsync();

            ViewBag.TotalEmployes = employes.Count;
            ViewBag.CongesEnAttente = await _context.DemandesConges
                .CountAsync(d => d.Statut == StatutConge.EnAttente);

            return View(employes);
        }
        public async Task<IActionResult> List()
        {
            var employes = await _context.Employes
                .Include(e => e.Poste)
                .ToListAsync();

            return View(employes);
        }

        public async Task<IActionResult> Details(int id)
        {
            var employe = await _context.Employes
                .Include(e => e.Poste)
                .Include(e => e.DemandesConges)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (employe == null)
                return NotFound();

            ViewBag.DemandesConges = employe.DemandesConges
                .OrderByDescending(d => d.DateDemande)
                .ToList();

            return View(employe);
        }


        public IActionResult Create()
        {
            ViewBag.Postes = new SelectList(_context.Postes, "Id", "Nom");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Employe employe)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Postes = new SelectList(_context.Postes, "Id", "Nom", employe.PosteId);
                TempData["ErrorMessage"] = "Veuillez remplir tous les champs obligatoires.";
                return View(employe);
            }

            _context.Employes.Add(employe);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Employé créé avec succès.";
            return RedirectToAction(nameof(Account));
        }


        public async Task<IActionResult> Edit(int id)
        {
            var employe = await _context.Employes.FindAsync(id);
            if (employe == null)
                return NotFound();

            ViewBag.Postes = new SelectList(_context.Postes, "Id", "Nom", employe.PosteId);
            return View(employe);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Employe employe)
        {
            if (id != employe.Id)
                return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.Postes = new SelectList(_context.Postes, "Id", "Nom", employe.PosteId);
                return View(employe);
            }

            _context.Update(employe);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Employé modifié avec succès.";
            return RedirectToAction(nameof(Account));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateDemandeConge(
            int employeId,
            DateTime dateDebut,
            DateTime dateFin,
            string motif)
        {
            // Sécurité
            if (dateDebut > dateFin)
            {
                TempData["ErrorMessage"] = "La date de début doit être avant la date de fin.";
                return RedirectToAction("Details", new { id = employeId });
            }

            var employe = await _context.Employes
                .Include(e => e.DemandesConges)
                .FirstOrDefaultAsync(e => e.Id == employeId);

            if (employe == null)
                return NotFound();

            var demande = new DemandeConge
            {
                EmployeId = employeId,
                DateDebut = dateDebut,
                DateFin = dateFin,
                Motif = motif,
                Statut = StatutConge.EnAttente,
                DateDemande = DateTime.Now
            };

            _context.DemandesConges.Add(demande);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Votre demande de congé a été envoyée avec succès.";

          
            return RedirectToAction("Details", new { id = employeId });
        }


        public async Task<IActionResult> Delete(int id)
        {
            var employe = await _context.Employes
                .Include(e => e.Poste)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (employe == null)
                return NotFound();

            return View(employe);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employe = await _context.Employes.FindAsync(id);
            if (employe != null)
            {
                _context.Employes.Remove(employe);
                await _context.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = "Employé supprimé.";
            return RedirectToAction(nameof(Account));
        }
    }
}
