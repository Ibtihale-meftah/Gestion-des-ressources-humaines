using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;

namespace GestionRH.API.Controllers
{
    public class DiagnosticController : Controller
    {
        private readonly AppDbContext _context;

        public DiagnosticController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> TestConnection()
        {
            try
            {
                var canConnect = await _context.Database.CanConnectAsync();
                var employesCount = await _context.Employes.CountAsync();
                var postesCount = await _context.Postes.CountAsync();
                var demandesCount = await _context.DemandesConges.CountAsync();

                return Json(new
                {
                    Success = true,
                    CanConnect = canConnect,
                    EmployesCount = employesCount,
                    PostesCount = postesCount,
                    DemandesCount = demandesCount,
                    ConnectionString = _context.Database.GetConnectionString()
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                    StackTrace = ex.StackTrace
                });
            }
        }

        public async Task<IActionResult> TestSave()
        {
            try
            {
                var testPoste = new Poste
                {
                    Nom = $"Test Poste {DateTime.Now:yyyyMMddHHmmss}",
                    JoursCongesAnnuels = 25
                };

                _context.Postes.Add(testPoste);
                var result = await _context.SaveChangesAsync();

                return Json(new
                {
                    Success = true,
                    RowsAffected = result,
                    PosteId = testPoste.Id,
                    Message = "Test de sauvegarde réussi"
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                    StackTrace = ex.StackTrace
                });
            }
        }
    }
}

