﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionRH.API.Models;

namespace GestionRH.API.Controllers
{
    public class PostesController : Controller
    {
        private readonly AppDbContext _context;

        public PostesController(AppDbContext context)
        {
            _context = context;
        }

     
        public async Task<IActionResult> Index()
        {
            return View(await _context.Postes.ToListAsync());
        }

       
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var poste = await _context.Postes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (poste == null)
            {
                return NotFound();
            }

            return View(poste);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nom,JoursCongesAnnuels")] Poste poste)
        {
            if (!ModelState.IsValid)
            {
                var errors = string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                TempData["ErrorMessage"] = $"Erreurs de validation : {errors}";
                return View(poste);
            }

            try
            {
                _context.Add(poste);
                var result = await _context.SaveChangesAsync();
                
                if (result > 0)
                {
                    TempData["SuccessMessage"] = $"Le poste {poste.Nom} a été créé avec succès.";
                }
                else
                {
                    TempData["ErrorMessage"] = "Aucune modification n'a été enregistrée.";
                }
                
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Erreur lors de la création : {ex.Message}";
                return View(poste);
            }
            return View(poste);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var poste = await _context.Postes.FindAsync(id);
            if (poste == null)
            {
                return NotFound();
            }
            return View(poste);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nom,JoursCongesAnnuels")] Poste poste)
        {
            if (id != poste.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(poste);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = $"Le poste {poste.Nom} a été modifié avec succès.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PosteExists(poste.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(poste);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var poste = await _context.Postes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (poste == null)
            {
                return NotFound();
            }

            return View(poste);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var poste = await _context.Postes.FindAsync(id);
            if (poste != null)
            {
                var nomPoste = poste.Nom;
                _context.Postes.Remove(poste);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Le poste {nomPoste} a été supprimé avec succès.";
            }
            else
            {
                TempData["ErrorMessage"] = "Le poste n'a pas été trouvé.";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool PosteExists(int id)
        {
            return _context.Postes.Any(e => e.Id == id);
        }
    }
}
